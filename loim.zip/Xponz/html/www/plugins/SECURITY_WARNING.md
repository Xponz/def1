----
# PLUGIN SECURITY WARNING #

----
Plugins are not sandboxed or restricted in any way and have full accesss
to your client system including your Nxt passphrase.

Make sure to only run plugins downloaded from trusted sources, otherwise
you can lose your NXT! In doubt don't log into the client with an account
used to store large amount of NXT now or in the future while plugins
are active.

Logging into the client without remembering the passphrase won't make
the process more secure.